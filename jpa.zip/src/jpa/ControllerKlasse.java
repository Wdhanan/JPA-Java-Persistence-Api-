package jpa;


import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;


public class ControllerKlasse {
	static Scanner ein =new Scanner(System.in);
	


	public static void main(String[]args) {
		try {
			EntityManager em= new Testview().connect();//baut die Verbindung auf und entsprechende Ausgaben werden in der View-Klasse ausgegeben
			
			Testview.auswahl(em);
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	    	 
	     } 
	
	public static void ArtikelDB(EntityManager em,Scanner ein) throws Exception {
		String auswahl;
        auswahl=ein.next();
		switch(auswahl) {
		case "anlegen":
			Artikel A=new Artikel();
			A.setAnr(8);
			A.setBezeichnung("Socken");
			A.setPreis(new BigDecimal(7.99));
			SimpleDateFormat d= new SimpleDateFormat("dd-MM-yyyy");
			Date date= d.parse("11-12-2021");
			A.setAngelegt( date);
			em.getTransaction().begin();//Transaktions-Begin
			ArtikelDB.anlegen(em, A);
			em.getTransaction().commit();
			Testview.anlegenArtikel(em);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
	        Testview.ArtikelDB2(em);
             break;
			
		case "aktualisieren":
			Artikel A1=new Artikel();
			A1.setAnr(2);
			A1.setBezeichnung("Smartphone");
			A1.setPreis(new BigDecimal(600.29));
			SimpleDateFormat d1= new SimpleDateFormat("dd-MM-yyyy");
			Date date1= d1.parse("15-02-2020");
			A1.setAngelegt(date1);
			em.getTransaction().begin();//Transaktions-Begin
			ArtikelDB.aktualisieren(em, A1);
			em.getTransaction().commit();
			Testview.aktualisierenArtikel(em);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
			Testview.ArtikelDB2(em);


			
			
			break;
			
		case "loeschen":

			em.getTransaction().begin();//Transaktions-Begin
			ArtikelDB.loeschen(em, 8);
			em.getTransaction().commit();
			Testview.loeschenArtikel(em);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
			Testview.ArtikelDB2(em);


			
			
			break;
			
		case "findArt":
			List<Artikel>list=ArtikelDB.findArt(em, new BigDecimal(100.99));
			Testview.findArtArtikel(em,list);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
			Testview.ArtikelDB2(em);
			
			
			break;
			
		case "findMitAnr":
			Artikel A3= ArtikelDB.findMitAnr(em, 3);
			Testview.findMitAnrArtikel(em,A3);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
			Testview.ArtikelDB2(em);			
			break;
		
		case "aktuList":
			List<Artikel>list2=new ArrayList<>();
			Artikel L1=new Artikel();
			L1.setAnr(1);
			L1.setBezeichnung("Socken");
			L1.setPreis(new BigDecimal(7.99));
			SimpleDateFormat d2= new SimpleDateFormat("dd-MM-yyyy");
			Date date5= d2.parse("11-12-2020");
			L1.setAngelegt( date5);
			Artikel L2=new Artikel();
			L2.setAnr(3);
			L2.setBezeichnung("Tasche");
			L2.setPreis(new BigDecimal(77.39));
			SimpleDateFormat d3= new SimpleDateFormat("dd-MM-yyyy");
			Date date6= d3.parse("11-12-2011");
			L2.setAngelegt( date6);
			Artikel L3=new Artikel();
			L3.setAnr(2);
			L3.setBezeichnung("Auto");
			L3.setPreis(new BigDecimal(70000.99));
			SimpleDateFormat d4= new SimpleDateFormat("dd-MM-yyyy");
			Date date7= d4.parse("01-05-2021");
			L3.setAngelegt( date7);
			Artikel L4=new Artikel();
			L4.setAnr(4);
			L4.setBezeichnung("Bleistift");
			L4.setPreis(new BigDecimal(7.99));
			SimpleDateFormat d5= new SimpleDateFormat("dd-MM-yyyy");
			Date date8= d5.parse("01-01-2021");
			L4.setAngelegt( date8);
			list2.add(L3);//in beliebiger Reihenfolge in der Liste einfugen
			list2.add(L1);
			list2.add(L2);
			list2.add(L4);
			List<Artikel> ergebnis=ArtikelDB.aktuList(em, list2);
			Testview.aktuListArtikel(em,ergebnis);
			Testview.ArtikelDB2(em);
	
			break;
			
		default:
        Testview.ArtikelDB3(em,ein);
			
			
		}
		
	}
	public static void LieferantDB(EntityManager em,Scanner ein) throws Exception {
		  String auswahl;
          auswahl=ein.next();
			switch(auswahl) {
			case "anlegen":
				Lieferant L=new Lieferant();
				L.setName("junior");
				L.setLnr(2);
				L.setPlz("65070");
				em.getTransaction().begin();//Transaktions-Begin
				LieferantDB.anlegen(em, L);
				em.getTransaction().commit();
				Testview.anlegenLieferant(em);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
                Testview.LieferantDB2(em);
                break;
			
				
			case "aktualisieren":
				Lieferant L1=new Lieferant();
				L1.setName("Joseph");
				L1.setPlz("60810");
				L1.setLnr(4);
				em.getTransaction().begin();//Transaktions-Begin
				LieferantDB.aktualisieren(em, L1);
				em.getTransaction().commit();
				Testview.aktualisierenLieferant(em);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
				Testview.LieferantDB2(em);
				
				break;
			
			case "loeschen":
				em.getTransaction().begin();//Transaktions-Begin
				LieferantDB.loeschen(em, 2);//nicht nur der Lieferant wird geloescht auch die Lieferung,bei der er auftritt wird geloescht
				em.getTransaction().commit();
				Testview.loeschenLieferant(em);////fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
				Testview.LieferantDB2(em);				
				break;
			
			case "findAll":
				List<Lieferant>li=LieferantDB.findAll(em);
				Testview.findAllLieferant(em,li);////fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
				Testview.LieferantDB2(em);

				break;
			
			case "findMitLnr":
				Lieferant L3=LieferantDB.findMitLnr(em, 1);
				Testview.findMitLnrLieferant(em, L3);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
				Testview.LieferantDB2(em);			
				
				break;
				
			case "findBetween":
				List<Lieferant>L4=LieferantDB.findBetween(em, 3, 6);
				Testview.findBetweenLieferant(em,L4);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
				Testview.LieferantDB2(em);
				
				
				break;
				
			default:
            Testview.LieferantDB3(em,ein);
				
			}
			
		
	}
	public static void LieferungDB(EntityManager em,Scanner ein) throws Exception {
        String auswahl;
		auswahl=ein.next();
	
		switch(auswahl) {
		case "anlegen":
			SimpleDateFormat d= new SimpleDateFormat("dd-MM-yyyy");
			Date date= d.parse("11-02-2011");
			Lieferung L= new Lieferung();
			L.setId(new LieferungPK(1,1));
			Artikel a=new Artikel();
			a.setAnr(1);
			a.setBezeichnung("Teppich");
			a.setPreis(new BigDecimal(295.99));
			a.setAngelegt(date);
			L.setArtikel(a);
			L.setLieferant(new Lieferant(1,"Moritz","6734"));
			L.setPreis(new BigDecimal(200.99));
			em.getTransaction().begin();//Transaktions-Begin
			LieferungDB.anlegen(em, L);
			em.getTransaction().commit();
			Testview.anlegenLieferung(em);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
            Testview.LieferungDB2(em);
			break;
			
			
		case "aktualisieren":
			SimpleDateFormat d1= new SimpleDateFormat("dd-MM-yyyy");
			Date date1= d1.parse("25-12-2017");
			Lieferung L1= new Lieferung();
			L1.setId(new LieferungPK(4,5));
			L1.setPreis(new BigDecimal(30.99));
			L1.setArtikel(new Artikel(5,"Hose",new BigDecimal(77.79),date1));
			L1.setLieferant(new Lieferant(4,"Wilfried","60897"));
			em.getTransaction().begin();
			LieferungDB.aktualisieren(em, L1);
			em.getTransaction().commit();
			Testview.aktualisierenLieferung(em);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
			Testview.LieferungDB2(em);
            break;
		case "loeschen":
			LieferungDB.loeschen(em,new LieferungPK(1,1));
			em.getTransaction().begin();//Transaktions-Begin
			Testview.loeschenLieferung(em);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
			em.getTransaction().commit();
			Testview.LieferungDB2(em);
			break;
			
		case "findMitLnr":
				List<Lieferung> li=LieferungDB.findMitLnr(em, 1 );//Alle Lieferungen Wobei der LNr 1 ist ,Sollen ausgegeben werden
			    Testview.findMitLnrLieferungDB(em, li);//fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
			    Testview.LieferungDB2(em);
                break;
				
		case "findMitAnr":
			List<Lieferung>li1=LieferungDB.findMitAnr(em, 3);//Alle Lieferungen Wobei der ANr 3 ist ,Sollen ausgegeben werden
			Testview.findMitAnrLieferung(em,li1);////fur die Ausgabe wird immer die Entsprechende Klasse in TestView Aufgerufen
			Testview.LieferungDB2(em);
             break;
			
		default:
         Testview.LieferungDB3(em, ein);
}
		
}
	
	
}
