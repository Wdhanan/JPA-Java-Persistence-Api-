package jpa;

import java.util.List;
import javax.persistence.EntityManager;
public class LieferantDB {
	
	public static void anlegen(EntityManager em,Lieferant l)throws Exception {
    em.persist(l);
}
	public static void aktualisieren(EntityManager em,Lieferant l)throws Exception {
       Lieferant c=em.find(Lieferant.class, l.getLnr());
		c.setName(l.getName());
		c.setPlz(l.getPlz());
}
	public static void loeschen(EntityManager em,long lNr)throws Exception {
        Lieferant c=em.find(Lieferant.class,lNr);
		em.remove(c);
}
	public static List<Lieferant> findAll(EntityManager em)throws Exception{
		return em.createNamedQuery("Lieferant.findAll",Lieferant.class).getResultList();
	}
	public static Lieferant findMitLnr(EntityManager em,long lnr)throws Exception {
		Lieferant l= em.find(Lieferant.class, lnr);
		return l;
	}
	@SuppressWarnings("unchecked")
	public static List<Lieferant>findBetween(EntityManager em,int min,int max)throws Exception{
		String a="SELECT l FROM Lieferant l WHERE l.lnr BETWEEN "+min +" AND "+max;
		List<Lieferant> li=em.createQuery(a).getResultList();
		return li;
}
}