package jpa;

import java.sql.SQLException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class LieferungDB {
	@PersistenceContext

	public static void anlegen(EntityManager em,Lieferung l)throws Exception {
		
		em.persist(l);
	    
		
	}
	public static void aktualisieren(EntityManager em,Lieferung l)throws Exception {
       Lieferung c=em.find(Lieferung.class, l.getId());
		c.setArtikel(l.getArtikel());
		c.setLieferant(l.getLieferant());
		c.setPreis(l.getPreis());
		em.merge(l);


	}
	
	public static void loeschen(EntityManager em,LieferungPK id)throws Exception {//Loeschen mit LieferungPK
        Lieferung c=em.find(Lieferung.class,id);
		em.remove(c);


	}
	public static void loeschenMitAnr(EntityManager em,long aNr) throws SQLException {
		em.getTransaction().begin();
		Lieferung c=em.find(Lieferung.class,aNr);
		em.remove(c);
		em.getTransaction().commit();
	}
	public static void loeschenMitLnr(EntityManager em,long lNr) throws SQLException {
		em.getTransaction().begin();
		Lieferung c=em.find(Lieferung.class,lNr);
		em.remove(c);
		em.getTransaction().commit();
	}
	@SuppressWarnings("unchecked")
	public static List<Lieferung> findMitLnr(EntityManager em,long lnr)throws Exception {
		String a="SELECT l FROM Lieferung l WHERE l.id.lnr LIKE "+lnr;
		List<Lieferung> li=em.createQuery(a).getResultList();
		return li;
	}
	@SuppressWarnings("unchecked")
	public static List<Lieferung> findMitAnr(EntityManager em,long anr)throws Exception {
		String a="SELECT l FROM Lieferung l WHERE l.id.anr LIKE "+anr;
		List<Lieferung> li=em.createQuery(a).getResultList();
		return li;
	}
}
