package jpa;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import javax.persistence.EntityManager;

public class ArtikelDB {
	public static void anlegen(EntityManager em, Artikel A) throws Exception {
     em.persist(A);
}

	public static void aktualisieren(EntityManager em, Artikel ar) throws Exception {
        Artikel c = em.find(Artikel.class, ar.getAnr());
		c.setAngelegt(ar.getAngelegt());
		c.setBezeichnung(ar.getBezeichnung());
		c.setPreis(ar.getPreis());
		em.merge(c);
}

	public static void loeschen(EntityManager em, long anr) throws SQLException {
        Artikel c = em.find(Artikel.class, anr);
		em.remove(c);
}

	public static Artikel findMitAnr(EntityManager em, long aNr) throws Exception {
		Artikel l = em.find(Artikel.class, aNr);
		return l;
	}

	@SuppressWarnings("unchecked")
	public static List<Artikel> findArt(EntityManager em, BigDecimal preis) throws Exception {
		String a = "SELECT l FROM Artikel l WHERE l.preis > " + preis;
		List<Artikel> li = em.createQuery(a).getResultList();
		return li;
	}
  public static List<Artikel> aktuList(EntityManager em, List<Artikel> li) throws Exception {
		Collections.sort(li);
        for (Artikel a : li) {
        aktualisieren(em, a);
}
		return li;
}
}
