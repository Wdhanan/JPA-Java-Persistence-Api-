package jpa;

import java.io.Serializable;
import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;


/**
 * The persistent class for the LIEFERANT database table.
 * 
 */
@Entity
@Table(name="LIEFERANT")
@NamedQueries({
@NamedQuery(name="Lieferant.findAll", query="SELECT l FROM Lieferant l"),
@NamedQuery(name="Lieferant.findMitLnr", query="SELECT l FROM Lieferant l WHERE l.lnr LIKE :lnr"),
@NamedQuery(name="Lieferant.findBetween", query="SELECT l FROM Lieferant l WHERE l.lnr BETWEEN :min AND :max")
})

public class Lieferant implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long lnr;

	private String name;

	private String plz;

	//bi-directional many-to-one association to Lieferung
	@OneToMany(mappedBy="lieferant")
	private List<Lieferung> lieferungs=new ArrayList<>();

	public Lieferant() {
	}
public Lieferant(long lnr, String name, String plz) {
		
		this.lnr = lnr;
		this.name = name;
		this.plz = plz;
	}

	public long getLnr() {
		return this.lnr;
	}

	public void setLnr(long lnr) {
		this.lnr = lnr;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPlz() {
		return this.plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public List<Lieferung> getLieferungs() {
		return this.lieferungs;
	}

	public void setLieferungs(List<Lieferung> lieferungs) {
		this.lieferungs = lieferungs;
	}

	public Lieferung addLieferung(Lieferung lieferung) {
		getLieferungs().add(lieferung);
		lieferung.setLieferant(this);

		return lieferung;
	}

	public Lieferung removeLieferung(Lieferung lieferung) {
		getLieferungs().remove(lieferung);
		lieferung.setLieferant(null);

		return lieferung;
	}
	public String toString() {
		return( "Lieferant [Lnr=" + lnr + "; name=" + name + ";Plz=" + plz + "]");



	}

}