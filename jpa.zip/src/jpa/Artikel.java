package jpa;

import java.io.Serializable;
import javax.persistence.*;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the ARTIKEL database table.
 * 
 */

@Entity
@Table(name="Artikel")
@NamedQueries({
@NamedQuery(name="Artikel.findAll", query="SELECT l FROM Artikel l"),
@NamedQuery(name="Artikel.findMitAnr", query="SELECT l FROM Artikel l WHERE l.anr LIKE :anr"),
@NamedQuery(name="Lieferant.findArt", query="SELECT l FROM Artikel l WHERE l.preis >= :preis")
})

public class Artikel implements Serializable ,Comparable<Artikel> {
	private static final long serialVersionUID = 1L;

	@Id
	private long anr;

	@Temporal(TemporalType.DATE)
	private Date angelegt;

	private String bezeichnung;

	private BigDecimal preis;

	//bi-directional many-to-one association to Lieferung
	@OneToMany(mappedBy="artikel")
	private List<Lieferung> lieferungs;

	public Artikel() {
	}
    public Artikel(long anr,String bez,BigDecimal preis,Date angelegt) {
    	this.anr=anr;
    	bezeichnung=bez;
    	this.preis=preis;
    	this.angelegt=angelegt;
    	
    }
    public Artikel(long anr,String bez,BigDecimal preis) {
    	
    	this.anr=anr;
    	bezeichnung=bez;
    	this.preis=preis;
    }
	public long getAnr() {
		return this.anr;
	}

	public void setAnr(long anr) {
		this.anr = anr;
	}

	public Date getAngelegt() {
		return this.angelegt;
	}

	public void setAngelegt(Date angelegt) {
		this.angelegt = angelegt;
	}

	public String getBezeichnung() {
		return this.bezeichnung;
	}

	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}

	public BigDecimal getPreis() {
		return this.preis;
	}

	public void setPreis(BigDecimal preis) {
		this.preis = preis;
	}

	public List<Lieferung> getLieferungs() {
		return this.lieferungs;
	}

	public void setLieferungs(List<Lieferung> lieferungs) {
		this.lieferungs = lieferungs;
	}

	public Lieferung addLieferung(Lieferung lieferung) {
		getLieferungs().add(lieferung);
		lieferung.setArtikel(this);
        return lieferung;
	}

	public Lieferung removeLieferung(Lieferung lieferung) {
		getLieferungs().remove(lieferung);
		lieferung.setArtikel(null);

		return lieferung;
	}

	public int compareTo(Artikel other) {
    return  (int) (anr - other.anr);
	}
	
	@Override
	public String toString() {
		return "Artikel [anr=" + anr + ", angelegt=" + angelegt + ", bezeichnung=" + bezeichnung + ", preis=" + preis + "]";
	}

}