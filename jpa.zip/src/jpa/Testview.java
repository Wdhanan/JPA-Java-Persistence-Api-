package jpa;

import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Testview {
	static Scanner ein =new Scanner(System.in);
	private static final String PERSISTENCE_UNIT_NAME = "TestJpa";
	
	public EntityManager connect() throws Exception{
	    System.out.println("== START ==");
	    EntityManagerFactory factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
	    EntityManager em = null;
	    try {
	      em = factory.createEntityManager();
	      System.out.println("== Verbindung OK ==");
	} catch (Exception ex) {
	      System.err.println("Es gab ein Problem: " + ex);
	    } 

	    return em;
	}  

	
	
	public static void auswahl(EntityManager em) throws Exception {
		
		System.out.println("===============Die m�gliche Klassen sind:=========================");
		System.out.println("ArtikelDB\n"+"LieferantDB\n"+"LieferungDB");
		String auswahl;
		System.out.println("=======Waehlen sie bitte eine Klasse Zwischen die folgende Klassen:==============");
		auswahl=ein.next();
		switch(auswahl) {
		case "ArtikelDB":
			ArtikelDB1(em);
			ein.close();
			break;
		case "LieferantDB":
			LieferantDB1(em);
			ein.close();
			break;
		case "LieferungDB":
			LieferungDB1(em);
			ein.close();
		    break;
		default:
			System.out.println("==============Falsche eingabe===============");
			em.close();
			ein.close();
		
		
	}
}

	public static void anlegenLieferant(EntityManager em) {
		System.out.println("============Neuer Lieferant angelegt============");
		
	}

	public static void aktualisierenLieferant(EntityManager em) {
		System.out.println("============Lieferant wurde aktualisiert============");
		
	}

	public static void loeschenLieferant(EntityManager em) {
		System.out.println("============Lieferant wurde geloescht============");
		
	}

	public static void findAllLieferant(EntityManager em, List<Lieferant> li) {
		for(Lieferant L:li) {
		      System.out.println( L.toString());
		      for(int i=0;i<L.getLieferungs().size();i++){
					
		    	 System.out.println( L.getLieferungs().get(i).toString());
				}
					System.out.println("===========================================================================");
					
				}

		
	}

	public static void findMitLnrLieferant(EntityManager em, Lieferant l3) {
		System.out.println(l3.toString());;
		for(int i=0;i<l3.getLieferungs().size();i++){
			
	    	 System.out.println( l3.getLieferungs().get(i).toString());
			}
		System.out.println("===========================================================================");
		
	}
		
	

	public static void findBetweenLieferant(EntityManager em, List<Lieferant> l4) {
		for(Lieferant L:l4) {
			 System.out.println( L.toString());
		      for(int i=0;i<L.getLieferungs().size();i++){
					
		    	 System.out.println( L.getLieferungs().get(i).toString());
				}
		      System.out.println("===========================================================================");
					
				}
		
	}


	public static void anlegenLieferung(EntityManager em) {
		System.out.println("====Neuer Datensatz angelegt======");
		
	}


	public static void aktualisierenLieferung(EntityManager em) {
		System.out.println("==== Datensatz wurde aktualisiert======");
		
	}


	public static void loeschenLieferung(EntityManager em) {
		System.out.println("==== Die entsprechende Lieferung wurde geloescht======");
		
	}


	public static void findMitLnrLieferungDB(EntityManager em, List<Lieferung> li) {
		for(Lieferung L:li) {
			System.out.println(L.toString());
			}
		
	}


	public static void findMitAnrLieferung(EntityManager em, List<Lieferung> li1) {
		for(Lieferung L:li1) {
			System.out.println(L.toString());
		}  
		
	}


	public static void anlegenArtikel(EntityManager em) {

		System.out.println("neuer Artikel angelegt");
		
	}


	public static void aktualisierenArtikel(EntityManager em) {
		System.out.println(" Artikel wurde aktualisiert");
		
	}


	public static void loeschenArtikel(EntityManager em) {
		System.out.println(" Artikel wurde geloescht");
		
	}


	public static void findArtArtikel(EntityManager em, List<Artikel> list) {
		for(Artikel A:list) {
			System.out.println(A.toString());
			 
			 for(int i=0;i<A.getLieferungs().size();i++) {
				System.out.println( A.getLieferungs().get(i).toString());
			  }
			 System.out.println("===========================================================================");
		}
		
		
			
		
	}


	public static void findMitAnrArtikel(EntityManager em, Artikel a3) {
		System.out.println(a3.toString());
		 for(int i=0;i<a3.getLieferungs().size();i++) {
				System.out.println( a3.getLieferungs().get(i).toString());
			  }
		 System.out.println("===========================================================================");
		
	}


	public static void aktuListArtikel(EntityManager em, List<Artikel> ergebnis) {
		for(Artikel A:ergebnis) {
			System.out.println(A.toString());
			 
}
			 System.out.println("===========================================================================");
		}
	public static void ArtikelDB1(EntityManager em) throws Exception {
		System.out.println("=======Die m�glichen aufrufbare Methoden von Artikel sind: ================");
		System.out.println("anlegen,aktualisieren,loeschen,findArt,findMitAnr,aktuList");
		System.out.println("W�hlen Sie bitte eine zu aufzurende Methode aus:");
		Scanner sc =new Scanner(System.in);
		ControllerKlasse.ArtikelDB(em, sc);
		sc.close();
		if(em.isOpen()) {
		ein.close();
		em.close();
		}
	}
	public static void ArtikelDB2(EntityManager em) throws Exception {
		String eingabe;
		System.out.println("=====Weiter Testen?(j/n)?=====");
		eingabe=ein.next();
		if(eingabe.equals("j"))
			ArtikelDB1(em);
		else if(eingabe.equals("n")|| !eingabe.equals("j"))
			System.out.println("===========ende===========");
		if(em.isOpen()) {
		ein.close();
		em.close();//Verbindung wird immer geschlossen,wenn es nicht gebraucht wird
		}
		
		
	}
	public static void ArtikelDB3(EntityManager em,Scanner ein) {
		System.out.println("Die entsprechende Methode existiert bei uns nicht ");
		System.out.println("==================ende====================");
		if(em.isOpen()) {
		ein.close();
		em.close();//Verbindung wird immer geschlossen,wenn es nicht gebraucht wird
		}
		
		
	}
	public static void LieferantDB1(EntityManager em) throws Exception {
		System.out.println("=======Die m�glichen aufrufbare Methoden von Lieferant sind: ================");
		System.out.println("anlegen,aktualisieren,loeschen,findAll,findMitLnr,findBetween");
		System.out.println("W�hlen Sie bitte eine zu aufzurende Methode aus:");
		Scanner sc =new Scanner(System.in);
		ControllerKlasse.LieferantDB(em, sc);
		sc.close();
		if(em.isOpen()) {
		ein.close();
		em.close();}
	}
	
   public static void LieferantDB2(EntityManager em) throws Exception  {
	   String eingabe;
		System.out.println("=====Weiter Testen?(j/n)?=====");
		eingabe=ein.next();
		if(eingabe.equals("j"))
			LieferantDB1(em);
		else if(eingabe.equals("n")|| !eingabe.equals("j"))
			System.out.println("===========ende===========");
		if(em.isOpen()) {
			ein.close();
			em.close();}//Verbindung wird immer geschlossen,wenn es nicht gebraucht wird
			
	}

    public static void LieferantDB3(EntityManager em,Scanner ein) {
        System.out.println("Die entsprechende Methode existiert bei uns nicht ");
		System.out.println("==================ende====================");
		if(em.isOpen()) {
		ein.close();
		em.close();//Verbindung wird immer geschlossen,wenn es nicht gebraucht wird
		}
     }
  
    public static void LieferungDB1(EntityManager em) throws Exception {
    	System.out.println("=======Die m�glichen aufrufbare Methoden von Lieferung sind: ================");
		System.out.println("anlegen,aktualisieren,loeschen,findMitLnr,findMitAnr");
		System.out.println("W�hlen Sie bitte eine zu aufzurende Methode aus:");
		Scanner sc =new Scanner(System.in);
		ControllerKlasse.LieferungDB(em, sc);
		sc.close();
		if(em.isOpen()) {
		ein.close();
		em.close();}
    }
    public static void LieferungDB2(EntityManager em) throws Exception {
    	String eingabe;
		System.out.println("=====Weiter Testen?(j/n)?=====");
		eingabe=ein.next();
		if(eingabe.equals("j"))
			LieferungDB1(em);
		else if(eingabe.equals("n")|| !eingabe.equals("j"))
		System.out.println("======ende=====");
		if(em.isOpen()) {
		em.close();//Verbindung wird immer geschlossen,wenn es nicht gebraucht wird
		ein.close();
		}
    }
    public static void LieferungDB3(EntityManager em,Scanner ein){
    	 System.out.println("Die entsprechende Methode existiert bei uns nicht ");
 		System.out.println("==================ende====================");
 		if(em.isOpen()) {
 		ein.close();
 		em.close();//Verbindung wird immer geschlossen,wenn es nicht gebraucht wird
 		}
    }




}
	
